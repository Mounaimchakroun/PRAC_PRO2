var searchData=
[
  ['barco_0',['Barco',['../classBarco.html#aea54a1f00318af549e695999ccf08e38',1,'Barco']]],
  ['borrar_5fregistro_5fciudades_1',['borrar_registro_ciudades',['../classBarco.html#a69824ab7315289394ef66e0c7547f4cd',1,'Barco']]]
];
