var searchData=
[
  ['hacer_5fviaje_0',['hacer_viaje',['../classCuenca.html#ab58884679b201cb3b22a286a01e9925e',1,'Cuenca']]]
];
