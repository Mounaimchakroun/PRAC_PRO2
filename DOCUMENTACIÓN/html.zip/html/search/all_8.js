var searchData=
[
  ['obtener_5farbol_5fde_5fbeneficios_0',['obtener_arbol_de_beneficios',['../classCuenca.html#ac0279f54060a04f21d032dd08266b171',1,'Cuenca']]]
];
